============
Installation
============


Download from https://www.curseforge.com/minecraft/mc-mods/pokecube-aoi and install as any normal forge mod!