Legends, Quests and Dimensions
-------

.. toctree::
   :maxdepth: 2
   
   legends_quests.rst
   added_dimensions.rst

