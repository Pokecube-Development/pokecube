========
Usage
========

This is a mod for minecraft, add to minecraft and run!

download here: https://www.curseforge.com/minecraft/mc-mods/pokecube-aoi